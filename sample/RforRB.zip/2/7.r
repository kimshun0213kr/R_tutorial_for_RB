arr3 <- array(1:24,c(24))      #1次元
arr4 <- array(1:24,c(4,6))     #2次元
arr5 <- array(1:24,c(3,4,2))   #3次元