mat1 <- matrix(c(1:6),byrow = FALSE)
mat2 <- matrix(1:12,c(3,4),byrow = TRUE)