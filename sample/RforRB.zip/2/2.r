moji <- "文字"
print(moji)