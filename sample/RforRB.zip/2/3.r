v <- TRUE
print(class(v))

v <- 23.4
print(class(v))

v <- 12L
print(class(v))

v <- 3+2i
print(class(v))

v <- "TDU"
print(class(v))

v <- charToRaw("Hello")
print(class(v))

v <- list(21.3,2L,"Hello")
print(class(v))