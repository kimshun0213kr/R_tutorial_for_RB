vec1 <- c(8,6,5,9,13)
mean1 <- mean(vec1)
mean_dev <- mean(abs(vec1-mean1))
range1 <- max(vec1)-min(vec1)