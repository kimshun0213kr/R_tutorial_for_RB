data1 <- read.csv("example.csv",header = TRUE,row.names = 1)
data_jap <- data1$jap