Mat_Q2_1 <- matrix(c(1:9),ncol = 3,nrow = 3,byrow = TRUE)
Mat_Q2_2 <- matrix(c(10:18),ncol = 3,nrow = 3,byrow = FALSE)
Mat_Q2_3 <- Mat_Q2_1 %*% Mat_Q2_2