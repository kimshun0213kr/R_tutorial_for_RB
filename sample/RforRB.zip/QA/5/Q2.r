data1 <- read.table("Q3.txt",header = FALSE,sep = "\t",skip=12)

summ <- summary(data1[,3])