data2 <- c(1:10)^-1
h_tmp <- sum(data2)/length(data2)
h_mean <- h_tmp^-1