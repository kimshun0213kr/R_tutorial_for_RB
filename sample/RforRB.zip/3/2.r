mat3 <- matrix(c(1:4),nrow = 2,ncol = 2)
