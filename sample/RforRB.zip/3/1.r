mat1 <- matrix(c(1:9),nrow = 3,ncol = 3)
mat2 <- matrix(c(10:18),nrow = 3,ncol = 3)