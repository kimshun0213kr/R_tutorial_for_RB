Mat_Q1_1 <- matrix(c(1:9),ncol = 3,nrow = 3,byrow = FALSE)
Mat_Q1_2 <- Mat_Q1*3