Mat_Q4_1 <- matrix(c(11:19),ncol = 3,nrow = 3,byrow = FALSE)
Mat_Q4_2 <- det(Mat_Q4_1)